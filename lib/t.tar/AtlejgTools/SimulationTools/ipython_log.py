# IPython log file


get_ipython().magic(u'pwd ')
get_ipython().magic(u'pwd ')
get_ipython().magic(u'pwd ')
get_ipython().magic(u'pwd ')
