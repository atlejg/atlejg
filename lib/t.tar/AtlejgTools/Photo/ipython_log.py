# IPython log file


get_ipython().magic(u'run -i optics.py')
show()
close('all')
get_ipython().magic(u'run -i optics.py')
close('all')
get_ipython().magic(u'run -i optics.py')
close('all')
get_ipython().magic(u'run -i optics.py')
