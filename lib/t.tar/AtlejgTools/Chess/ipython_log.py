# IPython log file


get_ipython().magic(u'run -i Chess.py anand1.pgn')
get_ipython().magic(u'run -i Chess.py anand1.pgn')
get_ipython().magic(u'run -i Chess.py anand1.pgn')
ch = 'a'
ch.upper()
from
adfa
file
get_ipython().magic(u'run -i Chess.py anand1.pgn')
get_ipython().magic(u'run -i Chess.py anand1.pgn')
tokens[0]
tokens[0][0]
tokens[0][1]
g.board.playere
g.board.player
get_ipython().magic(u'run -i Chess.py anand1.pgn')
get_ipython().magic(u'run -i Chess.py anand1.pgn')
get_ipython().magic(u'pdb')
get_ipython().magic(u'run -i Chess.py anand1.pgn')
get_ipython().magic(u'run -i Chess.py anand1.pgn')
b
b._pieces
b._pieces()
b.player
get_ipython().magic(u'run -i Chess.py anand1.pgn')
get_ipython().magic(u'run -i Chess.py anand1.pgn')
b.wpieces
b.wpieces.all
get_ipython().magic(u'run -i Chess.py anand1.pgn')
get_ipython().magic(u'run -i Chess.py anand1.pgn')
filter
get_ipython().magic(u'pinfo filter')
filter(lambda pc: pc.ptype == ptype and pc.is_alive, pcs.all)
pcs = b._pieces()
ptype = KNIGHT
filter(lambda pc: pc.ptype == ptype and pc.is_alive, pcs.all)
l=filter(lambda pc: pc.ptype == ptype and pc.is_alive, pcs.all)
l[0].ptype
l[1].ptype
l[1].is_alive
get_ipython().magic(u'run -i Chess.py anand1.pgn')
get_ipython().magic(u'run -i Chess.py anand1.pgn')
get_ipython().magic(u'pdb ')
get_ipython().magic(u'pdb')
import pdb
pdb
get_ipython().magic(u'run -i Chess.py anand1.pgn')
get_ipython().magic(u'run -i Chess.py anand1.pgn')
a = range(10)
filter(lambda x: x==2, a)
l=filter(lambda x: x==2, a)
l
l[0]
l=filter(lambda x: x>5, a)
l
ru
get_ipython().magic(u'run -i Chess.py anand1.pgn')
get_ipython().magic(u'run -i Chess.py anand1.pgn')
get_ipython().magic(u'run -i Chess.py anand1.pgn')
get_ipython().magic(u'run Chess.py anand1.pgn')
get_ipython().magic(u'run Chess.py anand1.pgn')
get_ipython().magic(u'pdb')
get_ipython().magic(u'run Chess.py anand1.pgn')
get_ipython().magic(u'run Chess.py anand1.pgn')
get_ipython().magic(u'run Chess.py anand1.pgn')
get_ipython().magic(u'run Chess.py anand1.pgn')
get_ipython().magic(u'run Chess.py anand1.pgn')
get_ipython().magic(u'run Chess.py anand1.pgn')
get_ipython().magic(u'run Chess.py anand1.pgn')
get_ipython().magic(u'run Chess.py anand1.pgn')
get_ipython().magic(u'pinfo pdb')
get_ipython().magic(u'pinfo pdb.set_trace')
get_ipython().magic(u'run Chess.py anand1.pgn')
get_ipython().magic(u'run Chess.py anand1.pgn')
get_ipython().magic(u'run Chess.py anand1.pgn')
get_ipython().magic(u'run Chess.py anand1.pgn')
get_ipython().magic(u'run Chess.py anand1.pgn')
get_ipython().magic(u'pdb')
get_ipython().magic(u'run Chess.py anand1.pgn')
get_ipython().magic(u'run Chess.py anand1.pgn')
get_ipython().magic(u'run Chess.py anand1.pgn')
get_ipython().magic(u'run Chess.py anand1.pgn')
get_ipython().magic(u'run Chess.py anand1.pgn')
get_ipython().magic(u'pdb')
get_ipython().magic(u'run Chess.py anand1.pgn')
get_ipython().magic(u'run Chess.py anand1.pgn')
get_ipython().magic(u'run Chess.py anand1.pgn')
get_ipython().magic(u'run Chess.py anand1.pgn')
get_ipython().magic(u'pdb')
get_ipython().magic(u'run Chess.py anand1.pgn')
get_ipython().magic(u'run Chess.py anand1.pgn')
get_ipython().magic(u'run Chess.py anand1.pgn')
get_ipython().magic(u'run Chess.py anand1.pgn')
get_ipython().magic(u'run Chess.py anand1.pgn')
get_ipython().magic(u'run Chess.py anand1.pgn')
b
print b
print b._to_string
print b._to_string()
ru
get_ipython().magic(u'run Chess.py anand1.pgn')
print b._to_string()
get_ipython().magic(u'run Chess.py anand1.pgn')
get_ipython().magic(u'pdb')
get_ipython().magic(u'run Chess.py anand1.pgn')
print b._to_string()
get_ipython().magic(u'run Chess.py anand1.pgn')
get_ipython().magic(u'run Chess.py anand1.pgn')
get_ipython().magic(u'run Chess.py anand1.pgn')
get_ipython().magic(u'run Chess.py anand1.pgn')
get_ipython().magic(u'run Chess.py anand1.pgn')
get_ipython().magic(u'run Chess.py anand1.pgn')
RANKS
RANKS.reverse()
RANKS
range(5)
range(0,5,-1)
range(5,0,-1)
range(7,-1,-1)
get_ipython().magic(u'run Chess.py anand1.pgn')
g.board.grid
g.board.grid[0][1]
g.board.grid[0][1].pc
g.board.grid[0][1].pos
g.board.grid[0][5].pos
g.board.grid[0]
[sq.pos for sq in g.board.grid[0]]
[sq.pos for sq in g.board.grid[76]]
[sq.pos for sq in g.board.grid[7]]
get_ipython().magic(u'run Chess.py anand1.pgn')
get_ipython().magic(u'run Chess.py anand1.pgn')
get_ipython().magic(u'run Chess.py anand1.pgn')
get_ipython().magic(u'run Chess.py anand1.pgn')
get_ipython().magic(u'run Chess.py anand1.pgn')
get_ipython().magic(u'run Chess.py anand1.pgn')
get_ipython().magic(u'run Chess.py anand1.pgn')
get_ipython().magic(u'run Chess.py anand1.pgn')
get_ipython().magic(u'run Chess.py anand1.pgn')
get_ipython().magic(u'run Chess.py anand1.pgn')
RANKS
range(7,-1,-1)
get_ipython().magic(u'run Chess.py anand1.pgn')
get_ipython().magic(u'run Chess.py anand1.pgn')
get_ipython().magic(u'run Chess.py anand1.pgn')
get_ipython().magic(u'run Chess.py anand1.pgn')
get_ipython().magic(u'run Chess.py anand1.pgn')
get_ipython().magic(u'run Chess.py anand1.pgn')
get_ipython().magic(u'run Chess.py anand1.pgn')
get_ipython().magic(u'run Chess.py anand1.pgn')
get_ipython().magic(u'run Chess.py anand1.pgn')
get_ipython().magic(u'run Chess.py anand1.pgn')
get_ipython().magic(u'run Chess.py anand1.pgn')
get_ipython().magic(u'run Chess.py anand1.pgn')
get_ipython().magic(u'run Chess.py anand1.pgn')
get_ipython().magic(u'run Chess.py anand1.pgn')
get_ipython().magic(u'run Chess.py anand1.pgn')
get_ipython().magic(u'run Chess.py anand1.pgn')
get_ipython().magic(u'run Chess.py anand1.pgn')
get_ipython().magic(u'run Chess.py anand1.pgn')
get_ipython().magic(u'run Chess.py anand1.pgn')
get_ipython().magic(u'run Chess.py anand1.pgn')
get_ipython().magic(u'run Chess.py anand1.pgn')
get_ipython().magic(u'run Chess.py anand1.pgn')
get_ipython().magic(u'run Chess.py anand1.pgn')
get_ipython().magic(u'pdb')
get_ipython().magic(u'run Chess.py anand1.pgn')
get_ipython().magic(u'run Chess.py anand1.pgn 6')
get_ipython().magic(u'run Chess.py anand1.pgn 6')
get_ipython().magic(u'run Chess.py anand1.pgn 6')
get_ipython().magic(u'run Chess.py anand1.pgn 22')
get_ipython().magic(u'run Chess.py anand1.pgn 23')
get_ipython().magic(u'run Chess.py anand1.pgn 24')
get_ipython().magic(u'run Chess.py anand1.pgn 24')
get_ipython().magic(u'run Chess.py anand1.pgn ')
get_ipython().magic(u'run Chess.py anand1.pgn')
get_ipython().magic(u'pinfo mod')
mod(2,2)
mod(5,2)
get_ipython().magic(u'run Chess.py anand1.pgn')
get_ipython().magic(u'run Chess.py anand1.pgn')
get_ipython().magic(u'run Chess.py anand1.pgn')
g.board.player
g.board.player
get_ipython().magic(u'run Chess.py anand1.pgn')
g.board.get_state()
get_ipython().magic(u'run Chess.py anand1.pgn')
g.board.get_state()
get_ipython().magic(u'run Chess.py anand1.pgn')
g.board.get_state()
get_ipython().magic(u'run Chess.py anand1.pgn')
g.board.get_state()
get_ipython().magic(u'pdb')
get_ipython().magic(u'run Chess.py anand1.pgn')
g.board.get_state()
m=g.board.get_state()
m.flatten()
v=m.flatten()
v
len(v)
get_ipython().magic(u'run Chess.py anand1.pgn')
m=g.board.get_state()
g.board.get_state()
get_ipython().magic(u'run Chess.py anand1.pgn')
m
get_ipython().magic(u'run Chess.py anand1.pgn')
m
array(m)
mm=array(m)
mm.shape
get_ipython().magic(u'run Chess.py anand1.pgn')
get_ipython().magic(u'run Chess.py anand1.pgn')
m
m.shape
get_ipython().magic(u'run Chess.py anand1.pgn')
show()
get_ipython().magic(u'run Chess.py anand2.pgn')
pgn_instructions
instructions
instructions[0]
instructions[1]
get_ipython().magic(u'run Chess.py anand2.pgn')
get_ipython().magic(u'run Chess.py anand2.pgn')
pgn_instructions
instructions[0]
instructions[1]
get_ipython().magic(u'run Chess.py anand2.pgn')
get_ipython().magic(u'run Chess.py anand2.pgn')
close('all')
get_ipython().magic(u'run Chess.py anand1.pgn')
get_ipython().magic(u'run Chess.py anand2.pgn')
axis('equal')
axis('equal')
l = open('carlsen_vs_anand_2013_wch.png').readlines()
l
get_ipython().magic(u'history ')
get_ipython().magic(u'run -i fix.py')
get_ipython().magic(u'run -i fix.py')
gm_
str(gm_)
type(gm_)
get_ipython().magic(u'run -i fix.py')
get_ipython().magic(u'run -i fix.py')
get_ipython().magic(u'run -i fix.py')
get_ipython().magic(u'run -i fix.py')
get_ipython().magic(u'run -i fix.py')
close('all')
get_ipython().magic(u'run Chess.py carlsen_vs_anand_2013_wch_??.pgn')
get_ipython().magic(u'run Chess.py carlsen_vs_anand_2013_wch_??.pgn')
UT
get_ipython().magic(u'run Chess.py carlsen_vs_anand_2013_wch_??.pgn')
show
show()
get_ipython().magic(u'run Chess.py carlsen_vs_anand_2013_wch_??.pgn')
get_ipython().magic(u'run Chess.py carlsen_vs_anand_2013_wch_??.pgn')
get_ipython().magic(u'run Chess.py carlsen_vs_anand_2013_wch_??.pgn')
get_ipython().magic(u'run Chess.py carlsen_vs_anand_2013_wch_??.pgn')
get_ipython().magic(u'run Chess.py TMP/carlsen_vs_anand_2013_wch_05.pgn')
get_ipython().magic(u'run Chess.py TMP/carlsen_vs_anand_2013_wch_05.pgn')
get_ipython().magic(u'run Chess.py TMP/carlsen_vs_anand_2013_wch_05.pgn')
get_ipython().magic(u'run Chess.py TMP/carlsen_vs_anand_2013_wch_05.pgn')
get_ipython().magic(u'run Chess.py TMP/carlsen_vs_anand_2013_wch_05.pgn')
get_ipython().magic(u'run Chess.py TMP/carlsen_vs_anand_2013_wch_05.pgn')
get_ipython().magic(u'run Chess.py TMP/carlsen_vs_anand_2013_wch_05.pgn')
get_ipython().magic(u'run Chess.py TMP/carlsen_vs_anand_2013_wch_05.pgn')
get_ipython().magic(u'run Chess.py TMP/carlsen_vs_anand_2013_wch_05.pgn')
get_ipython().magic(u'run Chess.py TMP/carlsen_vs_anand_2013_wch_05.pgn')
get_ipython().magic(u'run Chess.py TMP/carlsen_vs_anand_2013_wch_05.pgn')
close('all')
get_ipython().magic(u'run Chess.py TMP/carlsen_vs_anand_2013_wch_05.pgn')
q
get_ipython().magic(u'run Chess.py TMP/carlsen_vs_anand_2013_wch_05.pgn')
get_ipython().magic(u'run Chess.py TMP/carlsen_vs_anand_2013_wch_05.pgn')
get_ipython().magic(u'run Chess.py TMP/carlsen_vs_anand_2013_wch_05.pgn')
get_ipython().magic(u'run Chess.py TMP/carlsen_vs_anand_2013_wch_05.pgn')
get_ipython().magic(u'pdb')
get_ipython().magic(u'run Chess.py TMP/carlsen_vs_anand_2013_wch_05.pgn')
get_ipython().magic(u'run Chess.py TMP/carlsen_vs_anand_2013_wch_05.pgn')
get_ipython().magic(u'run Chess.py TMP/carlsen_vs_anand_2013_wch_05.pgn')
get_ipython().magic(u'run Chess.py TMP/carlsen_vs_anand_2013_wch_05.pgn')
0 < 1 < 2
if 0 < 1 < 2: print 1
get_ipython().magic(u'run Chess.py TMP/carlsen_vs_anand_2013_wch_05.pgn')
get_ipython().magic(u'run Chess.py TMP/carlsen_vs_anand_2013_wch_05.pgn')
get_ipython().magic(u'run Chess.py TMP/carlsen_vs_anand_2013_wch_05.pgn')
close('all')
get_ipython().magic(u'run Chess.py TMP/carlsen_vs_anand_2013_wch_05.pgn')
get_ipython().magic(u'run Chess.py TMP/carlsen_vs_anand_2013_wch_05.pgn')
pgn_instructions
close('all')
get_ipython().magic(u'run Chess.py TMP/carlsen_vs_anand_2013_wch_??.pgn')
get_ipython().magic(u'run Chess.py TMP/carlsen_vs_anand_2013_wch_02.pgn')
get_ipython().magic(u'run Chess.py TMP/carlsen_vs_anand_2013_wch_02.pgn')
get_ipython().magic(u'run Chess.py TMP/carlsen_vs_anand_2013_wch_02.pgn')
get_ipython().magic(u'run Chess.py TMP/carlsen_vs_anand_2013_wch_02.pgn')
get_ipython().magic(u'run Chess.py TMP/carlsen_vs_anand_2013_wch_02.pgn')
get_ipython().magic(u'run Chess.py TMP/carlsen_vs_anand_2013_wch_02.pgn')
get_ipython().magic(u'run Chess.py TMP/carlsen_vs_anand_2013_wch_02.pgn')
get_ipython().magic(u'run Chess.py TMP/carlsen_vs_anand_2013_wch_02.pgn')
get_ipython().magic(u'run Chess.py TMP/carlsen_vs_anand_2013_wch_02.pgn')
get_ipython().magic(u'run Chess.py TMP/carlsen_vs_anand_2013_wch_??.pgn')
close('all')
get_ipython().magic(u'run Chess.py TMP/carlsen_vs_anand_2013_wch_??.pgn')
close('all')
get_ipython().magic(u'run Chess.py TMP/carlsen_vs_anand_2013_wch_??.pgn')
get_ipython().magic(u'run Chess.py PGNs/carlsen_vs_anand_2013_wch_??.pgn')
close('all')
get_ipython().magic(u'run Chess.py PGNs/carlsen_vs_anand_2013_wch_??.pgn')
UT.hardcopies(10, 'Figs')
close('all')
rcParams
rcParams['figure.figsize']
get_ipython().magic(u'run Chess.py PGNs/carlsen_vs_anand_2013_wch_03.pgn')
get_ipython().magic(u'run Chess.py PGNs/carlsen_vs_anand_2013_wch_03.pgn')
close('all')
get_ipython().magic(u'run Chess.py PGNs/carlsen_vs_anand_2013_wch_??.pgn')
UT.hardcopies(10, 'Figs')
nmb = 1
nmb/8.*60
close('all')
get_ipython().magic(u'pinfo UT.grep_column')
UT.grep_column('PGNs/carlsen_vs_anand_2013_wch_01.pgn', 'Black', 2, False)
UT.grep_column('PGNs/carlsen_vs_anand_2013_wch_01.pgn', 'Black ', 2, False)
UT.grep_column('PGNs/carlsen_vs_anand_2013_wch_01.pgn', 'Black ', 2, False)[0]
UT.grep_column('PGNs/carlsen_vs_anand_2013_wch_01.pgn', 'Black ', 2, False)[0][1,-1]
UT.grep_column('PGNs/carlsen_vs_anand_2013_wch_01.pgn', 'Black ', 2, False)[0][1:-1]
UT.grep_column('PGNs/carlsen_vs_anand_2013_wch_07.pgn', 'Black ', 2, False)[0][1:-1]
UT.grep_column('PGNs/carlsen_vs_anand_2013_wch_07.pgn', 'Result ', 2, False)[0][1:-1]
UT.grep_column('PGNs/carlsen_vs_anand_2013_wch_07.pgn', 'Result ', 2, False)[0][1:-1]
close('all')
get_ipython().magic(u'run Chess.py PGNs/carlsen_vs_anand_2013_wch_??.pgn')
close('all')
get_ipython().magic(u'run Chess.py PGNs/carlsen_vs_anand_2013_wch_03.pgn')
close('all')
get_ipython().magic(u'run Chess.py PGNs/carlsen_vs_anand_2013_wch_??.pgn')
get_ipython().magic(u'pinfo UT.hardcopies')
UT.hardcopies(10, 'Figs', figno_only=True)
close('all')
UT.grep_column('PGNs/carlsen_vs_anand_2013_wch_07.pgn', 'Round ', 2, False)[0][1:-1]
UT.grep_column('PGNs/carlsen_vs_anand_2013_wch_07.pgn', 'Round ', 2, False)[0][1:-2]
get_ipython().magic(u'run Chess.py PGNs/carlsen_vs_anand_2013_wch_03.pgn')
close('all')
get_ipython().magic(u'run Chess.py PGNs/carlsen_vs_anand_2013_wch_??.pgn')
close('all')
get_ipython().magic(u'run Chess.py PGNs/carlsen_vs_anand_2013_wch_??.pgn')
UT.hardcopies(10, 'Figs', figno_only=True)
close('all')
get_ipython().magic(u'run -i Chess.py PGNs/carlsen_vs_anand_2013_wch_??.pgn')
close('all')
m.shape
m
g.board.get_state()
print(g.board)
