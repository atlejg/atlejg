# IPython log file


import AtlejgTools.FluidMechanics.PorousMedia as PM
PM.dp_radialflow(35, 35, 4, 9.5*U.INCH, 12, 50)
PM.dp_radialflow(35, 2.8, 4, 8.5*U.INCH, 12, 50)
