# IPython log file


[x[0][0] for x in v if x[0][0][0:1] in ['G1','F4','F1','E6','D5','E4']]
v = dd.get_raw_data('WSEGAICD', get_all=1)
dd = ECL.DataDeck('/project/RCP/active/reservoir_simulations/juvid/TROLL_FFM/./include/schedule/history_matching/hist2016/T-HM-W2016-10_ICD_CF_00.SCH')
v = dd.get_raw_data('WSEGAICD', get_all=1)
[x[0][0] for x in v if x[0][0][0:1] in ['G1','F4','F1','E6','D5','E4']]
[x[0][0] for x in v]
[x[0][0] for x in v if x[0][0][0:1] in ['G1','F4','F1','E6','D5','E4']]
x[0][0][0:1]
[x[0][0] for x in v if x[0][0][0:2] in ['G1','F4','F1','E6','D5','E4']]
[x[0][0] for x in v if x[0][0][0:2] in ['G1','F4','F1','E6','D5']]
ECL
